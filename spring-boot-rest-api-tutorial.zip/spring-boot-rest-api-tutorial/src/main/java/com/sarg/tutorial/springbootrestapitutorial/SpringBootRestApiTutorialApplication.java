package com.sarg.tutorial.springbootrestapitutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApiTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiTutorialApplication.class, args);
	}

}
