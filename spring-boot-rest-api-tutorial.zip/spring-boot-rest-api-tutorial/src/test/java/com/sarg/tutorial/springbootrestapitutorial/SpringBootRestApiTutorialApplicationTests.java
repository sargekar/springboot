package com.sarg.tutorial.springbootrestapitutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApiTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
